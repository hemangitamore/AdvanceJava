package com.example.RealationalMapping;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import com.example.RealationalMapping.OneToMany.Batch;
import com.example.RealationalMapping.OneToMany.Student;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Session session=  new Configuration().configure().addAnnotatedClass(Batch.class).addAnnotatedClass(Student.class).buildSessionFactory().openSession();
        session.beginTransaction();
        Batch b=new Batch();
        b.setName("JavaBatch");
        b.setStart_time(8);
        
        Student s1=new Student();
        s1.setName("Aditi");
        s1.setPhone("98765423");
        
        Student s2=new Student();
        s2.setName("Hemangi");
        s2.setPhone("98765563");
        
        s1.setBatch(b);
        s2.setBatch(b);
        
        b.getStudent().add(s1);
        b.getStudent().add(s2);
        session.save(b);
        session.save(s1);
        session.save(s1);
        
        session.getTransaction().commit();
        
        
        
        
    }
}
