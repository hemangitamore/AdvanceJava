package com.example.RealationalMapping.OneToMany;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity

public class Batch {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int id;
private String name;
private int start_time;

@OneToMany(mappedBy="batch")
List<Student>student=new ArrayList<>();

public Batch() {
	
}

public Batch(int id, String name, int start_time) {
	super();
	this.id = id;
	this.name = name;
	this.start_time = start_time;
	
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getStart_time() {
	return start_time;
}

public void setStart_time(int t) {
	this.start_time = t ;
}

public List<Student> getStudent() {
	return student;
}

public void setStudent(List<Student> student) {
	this.student = student;
}

@Override
public String toString() {
	return "Batch [id=" + id + ", name=" + name + ", start_time=" + start_time + "]";
}





}
