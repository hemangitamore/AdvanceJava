package com.example.DemoProject;

public class Laptop implements Hardware{
	private HardDisk hd;
	
	
	public HardDisk getHd() {
		return hd;
	}


	public void setHd(HardDisk hd) {
		this.hd = hd;
	}


	public void type() {
		System.out.println("Typing through keyboard");
		System.out.println("this are the harddisk specifications"+hd);
	}

}
