package com.example.DemoProject;

public interface Hardware {
	void type();

}
