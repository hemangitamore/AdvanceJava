package com.example.DemoProject;

public class HardDisk {
	private int ram;
	private String performance;
	
	public HardDisk() {
		ram=16;
		performance="Good";
	}
	public HardDisk(int ram, String performance) {
		super();
		this.ram = ram;
		this.performance = performance;
	}
	public int getRam() {
		return ram;
	}
	public void setRam(int ram) {
		this.ram = ram;
	}
	public String getPerformance() {
		return performance;
	}
	public void setPerformance(String performance) {
		this.performance = performance;
	}
	@Override
	public String toString() {
		return "HardDisk [ram=" + ram + ", performance=" + performance + "]";
	}
	
	
	
	

}
