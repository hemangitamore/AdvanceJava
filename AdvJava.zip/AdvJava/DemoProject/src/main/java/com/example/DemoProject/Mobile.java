package com.example.DemoProject;

public class Mobile implements Hardware {
	public void type() {
		System.out.println("Typing through display screen..");
	}

}
