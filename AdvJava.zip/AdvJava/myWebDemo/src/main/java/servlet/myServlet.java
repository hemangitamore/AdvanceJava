package servlet;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class myServlet extends HttpServlet {
	@Override
	public void init() throws ServletException {
		System.out.println("intit called");
	}
	
	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		System.out.println("service");
	}
	
	@Override
	public void destroy() {
		System.out.println("destroy called");
	}

}
