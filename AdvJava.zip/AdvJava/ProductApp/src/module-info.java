/**
 * 
 */
/**
 * 
 */
module ProductApp {
	requires java.sql;
}