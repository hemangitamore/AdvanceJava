package com.productApp.daoImpl;

import java.sql.SQLException;
import java.util.List;

import com.productApp.dao.productDao;
import com.productApp.model.Product;
import com.productApp.utility.sqlUtil;

public class productDaoImpl implements productDao{

	public int save(Product product) {
		int result=-1;
		try {
			sqlUtil.connectDb();
			String qry="INSERT INTO productInfo VALUES('"+product.getId1()+"','"+product.getName()+"','"+product.getPrice()+"')";
			sqlUtil.insert(qry);
			sqlUtil.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		} 
		
		return result;
	}

	public List<Product> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public Product getById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public int remove(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int update(int id, Product product) {
		// TODO Auto-generated method stub
		return 0;
	}
  
}
