package com.productApp;

import com.productApp.daoImpl.productDaoImpl;
import com.productApp.model.Product;

public class ProductApp {
	public static void main(String args[]) {
		Product p=new Product(1,"IPS Panel",7866);
		
		productDaoImpl productDaoImpl1 =new productDaoImpl();
		int result=productDaoImpl1.save(p);
		System.out.println(result);
	}

}
