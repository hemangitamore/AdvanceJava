package com.productApp.dao;

import java.util.List;

import com.productApp.model.Product;

public interface productDao {
	int save(Product product);
	List<Product>getAll();
	Product getById(int id);
	int remove(int id);
	int update(int id,Product product);
	
	

}
