package com.example.com.example.hibernate;

import org.hibernate.cfg.Configuration;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.engine.config.spi.ConfigurationService;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml").addAnnotatedClass(Prpduct.class).addAnnotatedClass(Employe.class);
		SessionFactory sf;
		
		sf = cfg.buildSessionFactory();

		Session session=sf.openSession();
	Transaction txn=session.beginTransaction();
		/*Prpduct p=new Prpduct();
		
		p.setId(102);
		p.setName("keybord");
		p.setPrice(1900);
		p.setQty(23);
		session.save(p);*/
	
	/*Employe emp=new Employe();
	emp.setName("Aditi");
	emp.setPhone("23456");
	emp.setSalary(8777);
	session.save(emp);*/
	
	 Employe emp=session.get(Employe.class,1);
	System.out.println(emp);
		
		txn.commit();
		
		session.close();
	}
}
