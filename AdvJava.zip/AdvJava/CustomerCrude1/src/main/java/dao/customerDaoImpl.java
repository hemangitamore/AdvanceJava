package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

public class customerDaoImpl implements customer{
	 private static final String URL = "jdbc:mysql://localhost:3306/yourdatabase";
	    private static final String USERNAME = "root";
	    private static final String PASSWORD = "root";

	    static {
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	    }
	@Override
	public void save(customer c) {
		try(Connection connection=DriverManager.getConnection(URL,USERNAME,PASSWORD)){
			String sql="Insert into customer(name,email) values(?,?)";
			try(PreparedStatement statment=connection.prepareStatement(sql)){
				PreparedStatement statement;
				statement.setString(1, c.getName());
				statement.setString(2, c.getEmail());
				statement.executeUpdate();
				
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
		
	}

	@Override
	public List<customer> getAllcustomer() {
		// TODO Auto-generated method stub
		return null;
	}

}
