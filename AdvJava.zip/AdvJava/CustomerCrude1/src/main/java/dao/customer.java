package dao;

import java.util.List;

public interface customer {
	void save(customer c);
	List<customer>getAllcustomer();
	

}
