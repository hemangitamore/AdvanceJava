package com.example.springJavaBasedConfig;

public interface Processor {
	void process();

}
