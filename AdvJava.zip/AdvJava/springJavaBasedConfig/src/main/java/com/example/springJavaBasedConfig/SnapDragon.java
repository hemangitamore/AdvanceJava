package com.example.springJavaBasedConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class SnapDragon implements Processor{
	@Autowired
	public void process() {
		System.out.println("snapdragon doing job");
	}

}
