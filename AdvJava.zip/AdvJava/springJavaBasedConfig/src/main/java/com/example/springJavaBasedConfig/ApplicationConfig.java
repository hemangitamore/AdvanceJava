package com.example.springJavaBasedConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackage="com.example.springJavaBasedConfig")
public class ApplicationConfig {
//	@Bean
//	public SamsungPhone getPhone() {
//		return new SamsungPhone();
//	}
//	
//	public Processor getProcessor() {
//		return new SnapDragon();
//	}
//	

}
