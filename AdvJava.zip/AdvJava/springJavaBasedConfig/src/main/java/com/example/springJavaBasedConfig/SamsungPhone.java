package com.example.springJavaBasedConfig;

import org.springframework.stereotype.Component;

@Component
public class SamsungPhone {
	Processor processor;
	public void specs() {
		System.out.println("Ram is 8GB,screen AMOLED 6.4inch");
		processor.process();
	}

}
