package com.example.hqlDemo;



import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import org.hibernate.query.Query;

import org.hibernate.Transaction;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       Configuration cfg=new Configuration();
       cfg.configure().addAnnotatedClass(Employe.class);
       Session session=cfg.buildSessionFactory().openSession();
       Transaction trn=session.beginTransaction();
       
       //String hql="SELECT E.name,E.phone FROM Employe E";
       Scanner sc=new Scanner(System.in);
       int id=sc.nextInt();
       String hql="SELECT E.name,E.phone FROM Employe E WHERE E.id=emp_id";
       //List result=session.createQuery(hql).list();
       Query qry=session.createQuery(hql);
       qry.setParameter("emp_id", id);
       List results =qry.list();
       Iterator itr = results.iterator();
      // Iterator itr=result.iterator();
       while(itr.hasNext()) {
    	   Object rs[]=(Object[]) itr.next();
    	   System.out.println(rs[0]+" "+rs[1]);
       }
    		   
       
       
    }
}
