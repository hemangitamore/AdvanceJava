package com.studentMvc.DaoImpl;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.studentMvc.Dao.studentDAO;
import com.studentMvc.model.Student;
import com.studentMvc.util.sqlUtil;

public class DaoImpl implements studentDAO {

	@Override
	public int save(Student student) {
		// TODO Auto-generated method stub
		int resut=-1;
		try {
			sqlUtil.connectDb();
			sqlUtil.conn.prepareStatement("Insert into student values(?,?,?,?,?,?");
			sqlUtil.stmt.setInt(1,student.getId());
			sqlUtil.stmt.setString(2,student.getName());
			sqlUtil.stmt.setString(3,student.getPhone());
			sqlUtil.stmt.setFloat(4,student.getMarks());
			sqlUtil.stmt.setString(5,student.getCity());
			sqlUtil.stmt.setString(6,student.getGender());
			
			
		}catch(Exception e) {
			
		}
		return 0;
	}

	@Override
	public List<Student> getAll() {
		List<Student>Students =new ArrayList<Student>();
		
		try {
			sqlUtil.connectDb();
			sqlUtil.stmt= sqlUtil.conn.prepareStatement("select * from student");
			ResultSet rs=sqlUtil.fetch();
			
			if(rs!=null) {
				while(rs.next()) {
					int id=rs.getInt("id");
					String name=rs.getString("name");
					String phone=rs.getString("phone");
					String city=rs.getString("city");
					String gender=rs.getString("gender");
					float marks=rs.getFloat("marks");
					Student student=new Student(id,name,phone,gender,marks,city);
					Students.add(student);
				}
			}
			sqlUtil.close();
			
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		return Students;
	}

	@Override
	public Student getById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int remove(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(int id, Student student) {
		// TODO Auto-generated method stub
		return 0;
	}

}
