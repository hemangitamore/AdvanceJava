package com.example.springDemo;

public interface Vehicle {
	void run();

}
