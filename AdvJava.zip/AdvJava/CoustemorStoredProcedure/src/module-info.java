/**
 * 
 */
/**
 * 
 */
module CoustemorStoredProcedure {
	requires java.sql;
	requires mysql.connector.j;
}