package Customer;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.cj.jdbc.CallableStatement;

public class customer {
	private static final String DB_USER="root";
	private static final String DB_PASSWORD="root";
	private static final String DB_NAME="customer";
	private static final String DB_URL="jdbc:mysql://localhost:3306/" + DB_NAME;
	
	
	private static Scanner sc=new Scanner(System.in);
	public static void select() {
		try(Connection conn=DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
				CallableStatement stmt=(CallableStatement) conn.prepareCall("{call selectperson()}");
				ResultSet set=stmt.executeQuery()){
			
			while(set.next()) {
				int id=set.getInt(1);
				String name=set.getString(2);
				Date date=set.getDate(3);
				System.out.println("id is "+id +",Name is"+ name+",Date is"+date);
			}
		}catch(Exception e) {
			System.out.println(e);
			
		}
				
				
	}
	
	public static void update() {
		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
	             CallableStatement stmt = (CallableStatement) conn.prepareCall("{call updatePerson(?,?,?)}")) {

	            System.out.println("Enter new ID, name, and date (YYYY-MM-DD):");
	            stmt.setInt(1, sc.nextInt());
	            stmt.setString(2, sc.next());
	            stmt.setDate(3, Date.valueOf(sc.next()));

	            int rows = stmt.executeUpdate();
	            if (rows > 0) {
	                System.out.println("Update successful");
	            }
	        } catch (SQLException e) {
	            System.err.println("Error executing update: " + e.getMessage());
	            e.printStackTrace();
	        }
	}
	
	
	public static void insert() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             CallableStatement stmt = (CallableStatement) conn.prepareCall("{call insertPerson(?,?,?)}")) {

            System.out.println("Enter ID:");
            stmt.setInt(1, sc.nextInt());
            System.out.println("Enter name:");
            stmt.setString(2, sc.next());
            System.out.println("Enter date (YYYY-MM-DD):");
            stmt.setDate(3, Date.valueOf(sc.next()));

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Data inserted successfully");
            }
        } catch (SQLException e) {
            System.err.println("Error executing insert: " + e.getMessage());
            e.printStackTrace();
        }
        
        
    }
	
	 public static void delete() {
	        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
	             CallableStatement stmt = (CallableStatement) conn.prepareCall("{call deletePerson(?)}")) {

	            System.out.println("Enter ID to delete:");
	            stmt.setInt(1, sc.nextInt());

	            int rows = stmt.executeUpdate();
	            if (rows > 0) {
	                System.out.println("Data deleted successfully");
	            }
	        } catch (SQLException e) {
	            System.err.println("Error executing delete: " + e.getMessage());
	            e.printStackTrace();
	        }
	    }
	 
	 public static int menu() {
	        System.out.println("\nMenu:");
	        System.out.println("1. Show Person");
	        System.out.println("2. Add Person");
	        System.out.println("3. Edit Person");
	        System.out.println("4. Delete Person");
	        System.out.print("Enter your choice (0 to exit): ");
	        return sc.nextInt();
	    }

	    public static void main(String[] args) {
	        int choice;
	        while ((choice = menu()) != 0) {
	            switch (choice) {
	                case 1:
	                    select();
	                    break;
	                case 2:
	                    insert();
	                    break;
	                case 3:
	                    update();
	                    break;
	                case 4:
	                    delete();
	                    break;
	                default:
	                    System.out.println("Invalid choice, please try again.");
	            }
	        }
	        System.out.println("Exiting program...");
	    }

	

}
