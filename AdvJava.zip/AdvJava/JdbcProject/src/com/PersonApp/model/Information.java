package com.PersonApp.model;

import java.time.LocalDate;

public class Information {
	private int id_person;
	private String name_person;
	private LocalDate DOB;
	
	public Information() {
		
	}
	
	public Information(int id_person, String name_person, LocalDate dOB) {
		super();
		this.id_person = id_person;
		this.name_person = name_person;
		DOB = dOB;
	}
	
	public int getId_person() {
		return id_person;
	}
	public void setId_person(int id_person) {
		this.id_person = id_person;
	}
	public String getName_person() {
		return name_person;
	}
	public void setName_person(String name_person) {
		this.name_person = name_person;
	}
	public LocalDate getDOB() {
		return DOB;
	}
	public void setDOB(LocalDate dOB) {
		DOB = dOB;
	}
	
	

	
	
	

}
