package com.PersonApp.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class sqlUtil {
	final static String DB_USER="root";
	final static String DB_PASSWORD="root";
	final static String DB_NAME="test1";
	final static String DB_URL="jdbc:mysql://localhost:3306/"+DB_NAME;
	final static String JDBC_DRIVER="com.mysql.cj.jdbc.Driver";
	static Statement stmt;
	static Connection conn;
	
	static void connectDb() throws ClassNotFoundException, SQLException {
		Class.forName(JDBC_DRIVER);
	conn=DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
	stmt=conn.createStatement();
	
	}
	
	
	
	
	

}
