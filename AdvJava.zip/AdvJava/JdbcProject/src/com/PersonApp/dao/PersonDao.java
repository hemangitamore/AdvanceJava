package com.PersonApp.dao;

public class PersonDao {
	public Person getPersonById(int id) {
		try(Connection connection= DBConnection.getConnection)
	}

}
