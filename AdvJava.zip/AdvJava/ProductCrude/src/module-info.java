/**
 * 
 */
/**
 * 
 */
module ProductCrude {
	requires java.sql;
}