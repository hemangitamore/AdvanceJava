package com.productapp.daoImpl;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.productapp.Model.student;
import com.productapp.Utility.sqlUtil;
import com.productapp.dao.StudentDao;

public class studentImpl implements StudentDao  {

	@Override
	public int save(student students) {
		int result=-1;
		try {
			sqlUtil.connectDb();
			String qry="INSERT INTO StudentInfo values('"+students.getId()+"','"+students.getName()+"','"+students.getPhone()+"','"+students.getGender()+"','"+students.getMarks()+"','"+students.getCity()+"')";
		result=sqlUtil.insert(qry);
		sqlUtil.close();
		}catch(Exception e) {
			System.out.println(e);
			
		}
		return result;
	}

	@Override
	public List<student> getAll() {
		List<student>students=new ArrayList<student>();
		try {
			sqlUtil.connectDb();
			String qry="Select * from StudentInfo";
			ResultSet rs=sqlUtil.fetch(qry);
			if(rs!=null) {
				while(rs.next()) {
					int id=rs.getInt("id");
					String name=rs.getString("name");
					String phone=rs.getString("phone") ;
					String gender=rs.getString("gender");
					double marks=rs.getDouble("marks");
					String city=rs.getString("city");
					student students1=new student(id,name,phone,gender,marks,city);
					students.add(students1);
				}
			}
			sqlUtil.close();
			
			}catch(Exception e) {
				System.out.println(e);
				
			}
		
		return students;
	}

	@Override
	public student getById(int id) {
		student students=null;
		try {
			sqlUtil.connectDb();
			String qry="select * from student where id="+id;
			ResultSet rs=sqlUtil.fetch(qry);
			if(rs!=null) {
				if(rs.next()) {
					int studentId=rs.getInt("id");
					String studentName=rs.getString("name");
					String studentPhone=rs.getString("phone");
					String studentgender=rs.getString("gender");
					double studentMarks=rs.getDouble("marks");
					String studentCity=rs.getString("city");
					students=new student();
					students.setId(studentId);
					students.setName(studentName);
					students.setPhone(studentPhone);
					students.setGender(studentgender);
					students.setMarks(studentMarks);
					students,
					}
			}
			
		}catch(Exception e) {
			System.out.println(e);
			
		}
		return null;
	}

	@Override
	public int remove(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(int id, student students) {
		// TODO Auto-generated method stub
		return 0;
	}

}
