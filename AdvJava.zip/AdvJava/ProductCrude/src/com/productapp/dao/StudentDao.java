package com.productapp.dao;

import java.util.List;

import com.productapp.Model.student;

public interface StudentDao {
	int save(student students );
	List<student>getAll();
	student getById(int id);
	int remove(int id);
	int update(int id,student students);
	

}
