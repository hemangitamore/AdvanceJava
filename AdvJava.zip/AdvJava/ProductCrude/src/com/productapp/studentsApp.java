package com.productapp;

import java.util.Iterator;
import java.util.List;

import com.productapp.Model.student;
import com.productapp.daoImpl.studentImpl;

public class studentsApp {
    public static void main(String[] args) {
        student s = new student(1, "Hemangi", "23456", "Female", 75.89, "Palghar");
        
        studentImpl studentsimpl = new studentImpl();
        int result = studentsimpl.save(s);
        System.out.println(result);
        
        // If you need to get all students
        List<student> studentsList = studentsimpl.getAll();
        for (student st : studentsList) {
            System.out.println(st);
        }
    }

    // Remove this method if not needed
    private static studentImpl studentImpl() {
        // Properly initialize and return an instance of studentImpl
        return new studentImpl();
    }
}
