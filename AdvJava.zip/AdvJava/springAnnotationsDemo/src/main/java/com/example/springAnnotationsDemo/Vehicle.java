package com.example.springAnnotationsDemo;

public interface Vehicle {
	void run();

}
