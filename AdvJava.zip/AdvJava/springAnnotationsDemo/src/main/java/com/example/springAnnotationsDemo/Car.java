package com.example.springAnnotationsDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


public class Car implements Vehicle {
	
	@Autowired
	private Engine engine;
	

	public Engine getEngine() {
		return engine;
	}


	public void setEngine(Engine engine) {
		this.engine = engine;
	}


	public void run() {
		System.out.println( " car is running");
		System.out.println("engine is" +engine);
	}

}
