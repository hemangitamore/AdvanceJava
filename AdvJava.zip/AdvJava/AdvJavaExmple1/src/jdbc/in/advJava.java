package jdbc.in;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.ResultSet;


public class advJava {
	public static void main(String args[]) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "root");
			Statement stmt=conn.createStatement();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter id:");
			int id=sc.nextInt();
			System.out.println("Enter name:");
			String name=sc.next();
			System.out.println("database connected");
			String qry="insert into info values('"+id+"','"+name+"')";
			//String qry="delete from info";
			int rs=stmt.executeUpdate(qry);
			System.out.println(rs+" rows effeceted");
			
			String qry1="select * from info";
			ResultSet rs1=stmt.executeQuery(qry1);
			while(rs1.next()) {
			    id=rs1.getInt("id");
			    name=	rs1.getString("name");
				System.out.println(id+" "+name);
			}
			stmt.close();
			conn.close();
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
			
	}

}
