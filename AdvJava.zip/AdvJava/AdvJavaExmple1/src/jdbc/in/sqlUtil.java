package jdbc.in;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class sqlUtil {
	final static String DB_USER="root";
	final static String DB_PASSWORD="root";
	final static String DB_NAME="student";
	final static String DB_URL="jdbc:mysql://localhost:3306/"+DB_NAME;
	final static String DRIVER_CLASS="com.mysql.cj.jdbc.Driver";
	static Statement stmt=null;
	static Connection conn=null;
	
	
	 static void connectDb() {
	        try {
	            Class.forName(DRIVER_CLASS);
	            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
	            stmt = conn.createStatement();
	        } catch (Exception e) {
	            System.out.println( e);
	        }
	    }
	
static int insert(String qry) {
		int result=-1;
		if(qry!="") {
		try {
			result =stmt.executeUpdate(qry);
			
		}catch(Exception e){
			System.out.println(e);
			
		}
		}
		return result;
		
	}

	
	



ResultSet fetch(String qry) {
	ResultSet rs1=null;
	
	if(qry!="") {
		try {
			rs1=stmt.executeQuery(qry);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	
	}
	return rs1;
	
}

static void close() {
	try {
		if(stmt!=null && conn!=null) {
			stmt.close();
			conn.close();
		}
		
	}catch(Exception e){
		System.out.println(e);
		
	}
}
}



