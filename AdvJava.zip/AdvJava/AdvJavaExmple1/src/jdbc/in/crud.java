package jdbc.in;

import java.util.Scanner;

public class crud {
  public static void main(String args[]) {
	  Scanner sc=new Scanner(System.in);
	  sqlUtil.connectDb();
	  System.out.println("Enter id:");
	  int id =sc.nextInt();
	  
	  System.out.println("Enter name:");
	  String name=sc.next();
	  String qry="insert into info values('"+id+"','"+name+"')";
	  int result=sqlUtil.insert(qry);
	  System.out.println(result);
	  sqlUtil.close();
  }
}
