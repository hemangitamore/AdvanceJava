/**
 * 
 */
/**
 * 
 */
module AdvJavaExmple1 {
	requires java.sql;
}