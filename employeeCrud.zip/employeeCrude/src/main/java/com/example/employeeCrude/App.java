package com.example.employeeCrude;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.example.employeeCrude.daoImpl.EmployeeDaoImpl;
import com.example.employeeCrude.model.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       Scanner sc=new Scanner(System.in);
       EmployeeDaoImpl employeeDaoImpl=new EmployeeDaoImpl();
       char continuationchoice;
       do {
    	   System.out.println("1.Add employee\n2.Get all Employees\n3. Get by id\n4. Remove Employee\n5. update\n6. Exit");
    	   System.out.print("Enter choice");
    	   int choice=sc.nextInt();
    	   if(choice==1) {
    		   Employee employee=new Employee();
    		   System.out.print("Enter name:");
    		   sc.nextLine();
    		   employee.setName(sc.nextLine());
    		   System.out.print("Enter phone:");
    		   employee.setPhone(sc.nextLine());
    		   System.out.print("Enter salary:");
    		   employee.setSalary(sc.nextFloat());
    		 int id=  employeeDaoImpl.save(employee);
    		 System.out.println("Inserted id:"+id);
    		   
    		   
    		   
    		   
    	   }else if(choice ==2) {
    		   List<Employee>employees=employeeDaoImpl.getAll();
    		   if(employees.size()==0) {
    			   System.out.println("No employee found..");
    		   }else{
    			   Iterator<Employee>itr=employees.iterator();
    			   while(itr.hasNext()) {
    				   Employee employee=itr.next();
    				   System.out.println(employee);
    			   }
    		    }

    		   }
    	   else if(choice==3) {
    		   System.out.println("Enter id you want to search:");
    		   int id=sc.nextInt();
    		   Employee employee=employeeDaoImpl.getById(id);
    		   if(employee!=null) {
    			   System.out.println(employee);
    		   }else {
    			   System.out.println("For given id Employee not found..");
    		   }
    		   
    	   }
    	   else if(choice==4) {
    		   System.out.println("Enter id:");
    		   int id=sc.nextInt();
    		  int result= employeeDaoImpl.remove(id);
    		  if(result!=-1) {
    			  System.out.println("Employe removed");
    		  }else {
    			  System.out.println("Employe with given id is not found..");
    		  }
    	   }else if(choice==5) {
    		   System.out.println("Enter id:");
    		   int id=sc.nextInt();
    		   
    		    
    		    System.out.println("Enter new name:");
    		    String name = sc.next();
    		    
    		    
    		    
    		    System.out.println("Enter new phone number:");
    		    String phone = sc.next();
    		    
    		    System.out.println("Enter new salary:");
    		    float salary = sc.nextFloat();
    		    
    		   int result= employeeDaoImpl.update( id, name, phone, salary);
    		   
    		    if (result == 1) {
    		        System.out.println("Employee updated successfully.");
    		    } else {
    		        System.out.println("Employee update failed.");
    		    }
    	   }else {
    		   System.out.println("Invalid choice");
    	   }
    	   System.out.println("Do you want to continue??(Y/N)");
    	   continuationchoice=sc.next().charAt(0);
    	   
       }while( continuationchoice=='Y');
    }
}
